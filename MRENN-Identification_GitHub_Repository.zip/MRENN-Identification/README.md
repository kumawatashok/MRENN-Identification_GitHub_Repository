# MRENN identification study: reference implementation

Code, configuration, raw per-seed results and figure/table generators for the manuscript
"Minimal-Regressor Recurrent Identification of Nonlinear Dynamical Systems: A Lyapunov Stable Alternative
to Order-Informed Feedforward Networks" (IEEE Access, Access-2026-41973).

Persistent address: https://doi.org/10.5281/zenodo.XXXXXXX  (replace after depositing this archive)

## Environment
- Python 3.10.12, NumPy 2.2.6 (double precision, single CPU thread). Matplotlib is needed only for figures.
- Install: `pip install -r requirements.txt`
- Seeds: 0 to 4 for evaluation (each seed also draws a new training excitation); seed 100 for hyperparameter selection.

## Layout
- `code/plants.py` six Narendra-Parthasarathy plants (seven sub-problems) and data generation, convention y_p(k+1) = F[.], e(k) = y_p(k+1) - y_hat(k+1).
- `code/regressors.py` regressors for the FNN, ENN and MRENN.
- `code/models.py` FNN (Adam), Elman (delta rule, truncated BPTT, Lyapunov rate), MRENN (diagonal context, second context layer, direct path, Lyapunov rate, projection).
- `code/core.py` training loop, metrics (RMSE, MAE, normalized RMSE, floor-protected MAPE), series-parallel and free-running prediction.
- `code/selection.py` hold-out hyperparameter selection (results in `results/sel/`, `results/selection_all.json`).
- `code/run_experiments.py` one (benchmark, seed, group) job; groups `main` (FNN, ENN, MRENN, ENN-BPTT, FNN-m, ENN-m) and `abl` (MRENN ablations).
- `code/aggregate.py`, `analysis.py`, `stats_all.py`, `diag_lyap.py` summaries, exact Wilcoxon and Friedman tests, numerical check of the descent condition.
- `code/make_tables.py`, `figs_arch.py`, `figs_res.py` regenerate `tables/*.tex` and `figures/*.png`.
- `code/export_csv.py` writes the JSON results to CSV files.
- `results/` raw per-seed outputs (`raw/`), `summary.json`, `numbers.json`, `selection_all.json`, `lyap_diag.json`, `timing.json`, and `csv/` (`metrics_per_seed.csv`, `statistics_and_ratios.csv`, `timing.csv`, `descent_check.csv`, `hyperparameter_selection.csv`).

## Reproduce
Run from `code/`:

    python3 selection.py MRENN; python3 selection.py ENN; python3 selection.py BPTT   # hyperparameter selection (optional, results included)
    for k in ex1 ex2 ex3 ex4 ex5 ex6; do for s in 0 1 2 3 4; do
        python3 run_experiments.py $k $s main; python3 run_experiments.py $k $s abl; done; done
    python3 aggregate.py; python3 analysis.py; python3 stats_all.py; python3 diag_lyap.py
    python3 make_tables.py; python3 figs_arch.py; python3 figs_res.py; python3 export_csv.py

Benchmark keys follow `plants.py`. `drive_exp.py`, `runq.py` and `loop.sh` run the same jobs in time-limited batches and can resume after an interruption.

## Notes
- Timing values in `results/timing.json` were measured with this NumPy implementation on one CPU core. They depend on the machine and are not portable.
- Floor-protected MAPE uses a denominator floor of 5 % of the peak absolute validation output and is an auxiliary metric only.
- The code uses simulated plants. A measured dataset can replace `plants.make_data` without other changes.

## License
MIT License. See `LICENSE`.

## Citation
If you use this code, please cite the manuscript above. Update this entry with the final reference after publication.
